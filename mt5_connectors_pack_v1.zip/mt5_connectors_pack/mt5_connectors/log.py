"""Standard-library logging helper (no third-party logger required)."""
import logging


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"mt5_connectors.{name}")
