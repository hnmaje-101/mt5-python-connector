"""Shared helpers: DataFrame normalization, UTC handling, resampling."""
from __future__ import annotations

from datetime import datetime, timezone

import numpy as np
import pandas as pd

TIMEFRAME_MINUTES = {
    "M1": 1, "M5": 5, "M15": 15, "M30": 30,
    "H1": 60, "H4": 240, "D1": 1440, "W1": 10080, "MN1": 43200,
}


def tf_minutes(timeframe: str) -> int:
    try:
        return TIMEFRAME_MINUTES[timeframe.upper()]
    except KeyError:
        raise ValueError(
            f"Invalid timeframe '{timeframe}'. Options: {list(TIMEFRAME_MINUTES)}"
        ) from None


def to_utc(dt: datetime | None) -> datetime | None:
    """Naive datetimes are assumed to be UTC."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def finalize_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """Return a clean OHLCV frame with a fixed column contract.

    Columns: open, high, low, close, tick_volume, spread, real_volume, log_return.
    Index: sorted, de-duplicated UTC DatetimeIndex.
    """
    df = df.copy()
    price_cols = ["open", "high", "low", "close"]
    for col in price_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=price_cols)
    for col in ("tick_volume", "spread", "real_volume"):
        if col not in df.columns:
            df[col] = 0
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype("int64")
    df = df[~df.index.duplicated(keep="last")].sort_index()
    ratio = df["close"] / df["close"].shift(1)
    df["log_return"] = np.log(ratio).replace([np.inf, -np.inf], 0.0).fillna(0.0)
    cols = price_cols + ["tick_volume", "spread", "real_volume", "log_return"]
    return df[cols + [c for c in df.columns if c not in cols]]


def drop_forming_candle(
    df: pd.DataFrame, timeframe: str, now: pd.Timestamp | None = None
) -> pd.DataFrame:
    """Drop the last row if that candle has not closed yet."""
    if df.empty:
        return df
    now = now or pd.Timestamp.now(tz="UTC")
    closes_at = df.index[-1] + pd.Timedelta(minutes=tf_minutes(timeframe))
    return df.iloc[:-1] if closes_at > now else df


def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    agg = {"open": "first", "high": "max", "low": "min", "close": "last"}
    if "tick_volume" in df.columns:
        agg["tick_volume"] = "sum"
    return df.resample(rule).agg(agg).dropna(subset=["open"])
