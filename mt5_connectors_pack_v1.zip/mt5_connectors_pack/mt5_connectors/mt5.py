"""Async MetaTrader 5 connector: market data + order execution.

The official MetaTrader5 package is synchronous (and Windows-only), so every
call runs in a worker thread, serialized by a lock.
"""
from __future__ import annotations

import asyncio
import math
import re
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pandas as pd

try:  # MetaTrader5 exists only on Windows (or under Wine)
    import MetaTrader5 as mt5
except ImportError:  # pragma: no cover
    mt5 = None

from .base import BaseConnector
from .exceptions import (
    MT5ConnectionError,
    MT5DataError,
    MT5OrderAmbiguousError,
    MT5OrderError,
)
from .log import get_logger
from .utils import TIMEFRAME_MINUTES, drop_forming_candle, finalize_ohlcv, to_utc

logger = get_logger("mt5")


def _tf_code(timeframe: str) -> int:
    key = timeframe.upper()
    if key not in TIMEFRAME_MINUTES:
        raise MT5DataError(
            f"Invalid timeframe '{timeframe}'. Options: {list(TIMEFRAME_MINUTES)}"
        )
    if mt5 is None:
        raise MT5DataError("MetaTrader5 package is not installed")
    return getattr(mt5, f"TIMEFRAME_{key}")


def _decimals(step: float) -> int:
    text = f"{step:.10f}".rstrip("0")
    return len(text.split(".")[1]) if "." in text else 0


class MT5Connector(BaseConnector):
    """Connector to a local MetaTrader 5 terminal.

    Args:
        login/password/server: account credentials. If omitted, the account
            already logged in inside the terminal is used.
        path: full path to terminal64.exe (optional).
        allow_trading: must be True to send REAL orders. Default False is a
            safety net; dry_run=True orders (order_check) always work.
        server_utc_offset_hours: broker server time vs UTC. MT5 labels candle
            times in *server time*. Set e.g. 2 or 3 to get true-UTC indexes.
            Default 0 keeps raw server time.
        connect_attempts: retries (exponential backoff 2s..30s) on connect().
        default_deviation / magic: defaults for orders.
        reconcile_attempts / reconcile_wait: after an AMBIGUOUS order response
            (timeout, lost reply) the connector polls MT5 this many times,
            this many seconds apart, before giving up. It NEVER resends by itself.
        idempotency_lookback_hours: history window used to detect that an
            order with the same client_id was already executed.
    """

    def __init__(
        self,
        login: int | None = None,
        password: str | None = None,
        server: str | None = None,
        path: str | None = None,
        *,
        allow_trading: bool = False,
        server_utc_offset_hours: float = 0.0,
        connect_attempts: int = 5,
        default_deviation: int = 20,
        magic: int = 0,
        reconcile_attempts: int = 5,
        reconcile_wait: float = 1.0,
        idempotency_lookback_hours: float = 24.0,
    ) -> None:
        self.login = login
        self._password = password
        self.server = server
        self.path = path
        self.allow_trading = allow_trading
        self.server_utc_offset_hours = server_utc_offset_hours
        self.connect_attempts = connect_attempts
        self.default_deviation = default_deviation
        self.magic = magic
        self.reconcile_attempts = reconcile_attempts
        self.reconcile_wait = reconcile_wait
        self.idempotency_lookback_hours = idempotency_lookback_hours
        self._connected = False
        self._lock: asyncio.Lock | None = None  # created lazily (loop-safe on 3.9)
        self._selected: set[str] = set()
        self._points: dict[str, float] = {}

    def __repr__(self) -> str:  # never expose the password
        return f"MT5Connector(login={self.login}, server={self.server!r})"

    # ── internals ─────────────────────────────────────────────

    async def _run(self, fn, *args, **kwargs):
        if self._lock is None:
            self._lock = asyncio.Lock()
        async with self._lock:
            return await asyncio.to_thread(fn, *args, **kwargs)

    def _to_server(self, dt: datetime) -> datetime:
        return to_utc(dt) + timedelta(hours=self.server_utc_offset_hours)

    def _to_utc_index(self, df: pd.DataFrame) -> pd.DataFrame:
        if self.server_utc_offset_hours:
            df.index = df.index - pd.Timedelta(hours=self.server_utc_offset_hours)
        return df

    async def _last_error(self):
        return await self._run(mt5.last_error)

    async def _ensure_symbol(self, symbol: str) -> None:
        if symbol in self._selected:
            return
        if not await self._run(mt5.symbol_select, symbol, True):
            raise MT5DataError(f"Symbol '{symbol}' not found / not selectable in MT5")
        self._selected.add(symbol)

    async def _point(self, symbol: str) -> float:
        if symbol not in self._points:
            info = await self._run(mt5.symbol_info, symbol)
            if info is None:
                raise MT5DataError(f"Symbol '{symbol}' not found in MT5")
            self._points[symbol] = info.point
        return self._points[symbol]

    # ── connection ────────────────────────────────────────────

    async def connect(self, max_attempts: int | None = None) -> None:
        if mt5 is None:
            raise MT5ConnectionError(
                "MetaTrader5 package is not installed (Windows only): "
                "pip install MetaTrader5"
            )
        if self.path and not Path(self.path).is_file():
            raise MT5ConnectionError(f"MT5 path does not exist: {self.path}")

        attempts = max_attempts or self.connect_attempts
        delay = 2.0
        for i in range(1, attempts + 1):
            try:
                await self._do_connect()
                break
            except MT5ConnectionError as exc:
                await self._run(mt5.shutdown)  # clean half-initialized state
                if i == attempts:
                    raise
                logger.warning("MT5 connect attempt %d/%d failed: %s", i, attempts, exc)
                await asyncio.sleep(delay)
                delay = min(delay * 2, 30.0)
        logger.info("MT5 connected (login=%s, server=%s)", self.login, self.server)

    async def _do_connect(self) -> None:
        kwargs: dict[str, Any] = {}
        if self.path:
            kwargs["path"] = self.path
        if self.login is not None:
            kwargs["login"] = int(self.login)
        if self._password:
            kwargs["password"] = self._password
        if self.server:
            kwargs["server"] = self.server
        if not await self._run(mt5.initialize, **kwargs):
            code, msg = await self._last_error()
            hint = ""
            if code in (-10001, -10003):
                hint = (
                    " | Open MetaTrader 5, log in to the server, keep the terminal "
                    "open, and run Python and MT5 under the same Windows user."
                )
            raise MT5ConnectionError(f"MT5 initialize() failed. Error {code}: {msg}{hint}")
        self._connected = True

    async def disconnect(self) -> None:
        if self._connected and mt5 is not None:
            await self._run(mt5.shutdown)
            self._connected = False
            self._selected.clear()
            logger.info("MT5 disconnected")

    async def is_connected(self) -> bool:
        if not self._connected or mt5 is None:
            return False
        info = await self._run(mt5.terminal_info)
        return bool(info is not None and info.connected)

    async def ping(self) -> dict[str, Any]:
        if mt5 is None:
            return {"connected": False}
        info = await self._run(mt5.terminal_info)
        if info is None:
            return {"connected": False}
        return {
            "connected": info.connected,
            "trade_allowed": info.trade_allowed,
            "ping_last": info.ping_last,
            "community_connection": info.community_connection,
        }

    # ── account / symbol ──────────────────────────────────────

    async def get_account_summary(self) -> dict[str, Any]:
        info = await self._run(mt5.account_info)
        if info is None:
            return {}
        return {
            "balance": info.balance, "equity": info.equity, "margin": info.margin,
            "free_margin": info.margin_free, "margin_level": info.margin_level,
            "leverage": info.leverage, "currency": info.currency,
            "server": info.server, "trade_mode": info.trade_mode,
        }

    async def get_symbol_info(self, symbol: str) -> dict[str, Any]:
        info = await self._run(mt5.symbol_info, symbol)
        if info is None:
            raise MT5DataError(f"Symbol '{symbol}' not found in MT5")
        tick = await self._run(mt5.symbol_info_tick, symbol)
        return {
            "symbol": info.name, "description": info.description,
            "currency_base": info.currency_base, "currency_profit": info.currency_profit,
            "digits": info.digits, "point": info.point, "spread": info.spread,
            "tick_size": info.trade_tick_size, "tick_value": info.trade_tick_value,
            "volume_min": info.volume_min, "volume_max": info.volume_max,
            "volume_step": info.volume_step, "filling_mode": info.filling_mode,
            "trade_mode": info.trade_mode,
            "current_bid": tick.bid if tick else None,
            "current_ask": tick.ask if tick else None,
            "current_spread": round((tick.ask - tick.bid) / info.point, 1) if tick else None,
        }

    # ── market data ───────────────────────────────────────────

    async def get_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        bars: int | None = 500,
        from_date: datetime | None = None,
        closed_only: bool = True,
    ) -> pd.DataFrame:
        """Candles from MT5.

        Without from_date: the last `bars` candles (honours `bars` for every
        timeframe). With from_date: all candles from that date to now, capped
        to the last `bars` if given. closed_only excludes the forming candle.
        Raises MT5DataError when there is no data.
        """
        tf = timeframe.upper()
        tf_code = _tf_code(tf)
        await self._ensure_symbol(symbol)

        if from_date is not None:
            rates = await self._run(
                mt5.copy_rates_range, symbol, tf_code, self._to_server(from_date),
                datetime.now(timezone.utc) + timedelta(hours=self.server_utc_offset_hours),
            )
        else:
            if not bars or bars < 1:
                raise ValueError("bars must be >= 1 when from_date is not given")
            rates = await self._run(
                mt5.copy_rates_from_pos, symbol, tf_code, 1 if closed_only else 0, int(bars)
            )

        if rates is None or len(rates) == 0:
            raise MT5DataError(
                f"No data for {symbol}/{tf}. MT5 error: {await self._last_error()}"
            )

        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df = self._to_utc_index(finalize_ohlcv(df.set_index("time")))
        if from_date is not None:
            if closed_only:
                df = drop_forming_candle(df, tf)
            if bars:
                df = df.tail(int(bars))
        return df

    async def get_ticks(
        self,
        symbol: str,
        from_date: datetime,
        to_date: datetime | None = None,
        count: int = 10_000,
    ) -> pd.DataFrame:
        """Tick data. Without to_date it asks MT5 for `count` ticks from
        from_date (memory-friendly); with to_date it fetches the range."""
        await self._ensure_symbol(symbol)
        start = self._to_server(from_date)
        if to_date is None:
            ticks = await self._run(mt5.copy_ticks_from, symbol, start, int(count), mt5.COPY_TICKS_ALL)
        else:
            ticks = await self._run(
                mt5.copy_ticks_range, symbol, start, self._to_server(to_date), mt5.COPY_TICKS_ALL
            )
        if ticks is None or len(ticks) == 0:
            raise MT5DataError(f"No ticks for {symbol}. MT5 error: {await self._last_error()}")

        df = pd.DataFrame(ticks)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df["time_msc"] = pd.to_datetime(df["time_msc"], unit="ms", utc=True)
        df = self._to_utc_index(df.set_index("time_msc").sort_index())
        point = await self._point(symbol)
        df["spread_points"] = ((df["ask"] - df["bid"]) / point).round(1)
        return df.head(int(count))

    async def get_current_price(self, symbol: str) -> dict[str, Any]:
        await self._ensure_symbol(symbol)
        tick = await self._run(mt5.symbol_info_tick, symbol)
        if tick is None:
            raise MT5DataError(f"Could not get a price for {symbol}")
        point = await self._point(symbol)
        return {
            "symbol": symbol, "bid": tick.bid, "ask": tick.ask, "last": tick.last,
            "spread_points": round((tick.ask - tick.bid) / point, 1),
            "time": datetime.fromtimestamp(tick.time, tz=timezone.utc)
            - timedelta(hours=self.server_utc_offset_hours),
            "volume": tick.volume, "source": "mt5", "estimated": False,
        }

    # ── order execution ───────────────────────────────────────
    #
    # Safety model: orders are NEVER resent automatically. Every order carries
    # a client_id (tagged into the MT5 comment as "#<id>"). If the reply is
    # ambiguous, the connector reconciles against MT5 (open positions + deal
    # history) before deciding. Callers that retry must pass the SAME
    # client_id: if that order already executed, it is returned instead of
    # being sent again.

    def _require_trading(self, dry_run: bool) -> None:
        if not dry_run and not self.allow_trading:
            raise MT5OrderError(
                "Trading is disabled. Create the connector with allow_trading=True "
                "to send real orders (or use dry_run=True to validate only)."
            )

    @staticmethod
    def _filling(info) -> int:
        fm = info.filling_mode
        if fm & mt5.SYMBOL_FILLING_IOC:
            return mt5.ORDER_FILLING_IOC
        if fm & mt5.SYMBOL_FILLING_FOK:
            return mt5.ORDER_FILLING_FOK
        return mt5.ORDER_FILLING_RETURN

    @staticmethod
    def _ambiguous_codes() -> set:
        return {
            mt5.TRADE_RETCODE_TIMEOUT, mt5.TRADE_RETCODE_CONNECTION, mt5.TRADE_RETCODE_ERROR,
        }

    @staticmethod
    def _client_id(client_id: str | None) -> str:
        if client_id is None:
            return uuid.uuid4().hex[:8]
        if not re.fullmatch(r"[A-Za-z0-9]{4,12}", client_id):
            raise MT5OrderError("client_id must be 4-12 letters/digits")
        return client_id

    @staticmethod
    def _tag(comment: str, cid: str) -> str:
        tag = f"#{cid}"
        return comment[: 31 - len(tag)] + tag  # MT5 comments max 31 chars

    @staticmethod
    def _result_dict(result, cid: str | None, reconciled: bool = False) -> dict[str, Any]:
        return {
            "retcode": result.retcode, "comment": result.comment, "dry_run": False,
            "order": getattr(result, "order", 0), "deal": getattr(result, "deal", 0),
            "volume": getattr(result, "volume", 0.0), "price": getattr(result, "price", 0.0),
            "client_id": cid, "reconciled": reconciled, "already_executed": False,
        }

    async def _find_by_cid(
        self, cid: str, symbol: str | None = None, since: datetime | None = None
    ) -> dict[str, Any] | None:
        """Look for an execution tagged with cid: open positions first, then deal history."""
        now = datetime.now(timezone.utc)
        since = since or now - timedelta(hours=self.idempotency_lookback_hours)
        positions = (await self._run(mt5.positions_get, symbol=symbol)) if symbol \
            else (await self._run(mt5.positions_get))
        for p in positions or ():
            if cid in (p.comment or ""):
                return {"kind": "position", "position": p.ticket, "volume": p.volume,
                        "price": p.price_open}
        deals = await self._run(
            mt5.history_deals_get, self._to_server(since), self._to_server(now + timedelta(days=1))
        )
        for d in deals or ():
            if cid in (d.comment or ""):
                return {"kind": "deal", "deal": d.ticket, "order": d.order,
                        "position": d.position_id, "volume": d.volume, "price": d.price}
        return None

    async def reconcile(self, client_id: str, symbol: str | None = None) -> dict[str, Any] | None:
        """Public: was an order with this client_id executed? Returns its
        position/deal info, or None if MT5 shows nothing."""
        return await self._find_by_cid(client_id, symbol)

    async def _find_execution(self, request, cid, started) -> dict[str, Any] | None:
        if request["action"] == mt5.TRADE_ACTION_SLTP:
            pos = await self._run(mt5.positions_get, ticket=request["position"])
            if pos and abs(pos[0].sl - request["sl"]) < 1e-6 and abs(pos[0].tp - request["tp"]) < 1e-6:
                return {"kind": "position", "position": pos[0].ticket}
            return None
        found = await self._find_by_cid(cid, request["symbol"], since=started)
        if found:
            return found
        if "position" in request:  # closing order: the position being gone = closed
            if not await self._run(mt5.positions_get, ticket=request["position"]):
                return {"kind": "closed", "position": request["position"]}
        return None

    async def _resolve_ambiguous(self, request, cid, started, result) -> dict[str, Any]:
        code = getattr(result, "retcode", None)
        logger.warning(
            "Ambiguous order response (retcode=%s, client_id=%s): reconciling with MT5, "
            "NOT resending", code, cid,
        )
        query_failed = False
        for attempt in range(max(1, self.reconcile_attempts)):
            try:
                found = await self._find_execution(request, cid, started)
            except Exception as exc:
                query_failed = True
                logger.warning("Reconcile query failed: %s", exc)
                found = None
            else:
                query_failed = False
            if found:
                logger.info("Order reconciled: it WAS executed (%s)", found)
                return {
                    "retcode": code, "comment": "reconciled after ambiguous response",
                    "dry_run": False, "client_id": cid, "reconciled": True,
                    "already_executed": False, **found,
                }
            if attempt + 1 < self.reconcile_attempts:
                await asyncio.sleep(self.reconcile_wait)
        raise MT5OrderAmbiguousError(
            f"Order outcome UNKNOWN (retcode={code}, client_id={cid}). "
            + ("MT5 queries failed: do NOT retry blindly. " if query_failed else
               "No execution found after reconciling; call reconcile(client_id) once more "
               "before retrying with the SAME client_id. ")
            + f"MT5 error: {await self._last_error()}",
            client_id=cid, not_found=not query_failed, retcode=code,
        )

    async def _send(self, request, dry_run: bool, cid: str | None = None) -> dict[str, Any]:
        if dry_run:
            result = await self._run(mt5.order_check, request)
            if result is None:
                raise MT5OrderError(f"order_check returned nothing: {await self._last_error()}")
            if result.retcode != 0:
                raise MT5OrderError(
                    f"Order check failed. retcode={result.retcode}: {result.comment}",
                    retcode=result.retcode,
                )
            return {"retcode": 0, "comment": result.comment, "dry_run": True, "client_id": cid}

        started = datetime.now(timezone.utc) - timedelta(minutes=2)
        try:
            result = await self._run(mt5.order_send, request)
        except Exception as exc:
            logger.warning("order_send raised %s: %s", type(exc).__name__, exc)
            result = None
        if result is None or result.retcode in self._ambiguous_codes():
            return await self._resolve_ambiguous(request, cid, started, result)
        ok_codes = {mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED, mt5.TRADE_RETCODE_DONE_PARTIAL}
        if result.retcode not in ok_codes:  # definite rejection: nothing was executed
            raise MT5OrderError(
                f"Order rejected. retcode={result.retcode}: {result.comment}",
                retcode=result.retcode,
            )
        return self._result_dict(result, cid)

    @staticmethod
    def _existing_result(found: dict[str, Any], cid: str) -> dict[str, Any]:
        return {"retcode": None, "comment": "already executed (idempotent)", "dry_run": False,
                "client_id": cid, "reconciled": True, "already_executed": True, **found}

    async def market_order(
        self,
        symbol: str,
        side: str,
        volume: float,
        sl: float | None = None,
        tp: float | None = None,
        deviation: int | None = None,
        magic: int | None = None,
        comment: str = "",
        dry_run: bool = False,
        client_id: str | None = None,
    ) -> dict[str, Any]:
        """Send a market order. side: 'buy' | 'sell'.

        client_id (4-12 letters/digits) makes the call idempotent: if an order with
        that id already executed, it is returned (already_executed=True) and
        NOTHING is sent. Always reuse the same client_id when retrying a failed
        or ambiguous order. Volume is validated and rounded DOWN to the step.
        """
        self._require_trading(dry_run)
        side = side.lower()
        if side not in ("buy", "sell"):
            raise MT5OrderError("side must be 'buy' or 'sell'")
        cid = self._client_id(client_id)
        await self._ensure_symbol(symbol)
        if client_id is not None and not dry_run:
            existing = await self._find_by_cid(cid, symbol)
            if existing:
                return self._existing_result(existing, cid)

        info = await self._run(mt5.symbol_info, symbol)
        tick = await self._run(mt5.symbol_info_tick, symbol)
        if info is None or tick is None:
            raise MT5OrderError(f"No symbol info / price for {symbol}")
        if volume < info.volume_min - 1e-12 or volume > info.volume_max + 1e-12:
            raise MT5OrderError(
                f"Volume {volume} outside allowed range [{info.volume_min}, {info.volume_max}]"
            )
        step = info.volume_step or info.volume_min
        vol = round(math.floor(volume / step + 1e-9) * step, _decimals(step))

        request: dict[str, Any] = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": vol,
            "type": mt5.ORDER_TYPE_BUY if side == "buy" else mt5.ORDER_TYPE_SELL,
            "price": tick.ask if side == "buy" else tick.bid,
            "deviation": deviation if deviation is not None else self.default_deviation,
            "magic": magic if magic is not None else self.magic,
            "comment": self._tag(comment, cid), "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": self._filling(info),
        }
        if sl:
            request["sl"] = round(float(sl), info.digits)
        if tp:
            request["tp"] = round(float(tp), info.digits)
        return await self._send(request, dry_run, cid)

    async def get_positions(self, symbol: str | None = None) -> list[dict[str, Any]]:
        positions = await self._run(mt5.positions_get, symbol=symbol) if symbol else \
            await self._run(mt5.positions_get)
        out = []
        for p in positions or []:
            out.append({
                "ticket": p.ticket, "symbol": p.symbol,
                "side": "buy" if p.type == mt5.POSITION_TYPE_BUY else "sell",
                "volume": p.volume, "price_open": p.price_open, "price_current": p.price_current,
                "sl": p.sl, "tp": p.tp, "profit": p.profit, "magic": p.magic,
                "comment": p.comment,
                "time": datetime.fromtimestamp(p.time, tz=timezone.utc)
                - timedelta(hours=self.server_utc_offset_hours),
            })
        return out

    async def _get_position(self, ticket: int):
        pos = await self._run(mt5.positions_get, ticket=int(ticket))
        if not pos:
            raise MT5OrderError(f"Position {ticket} not found")
        return pos[0]

    async def close_position(
        self,
        ticket: int,
        volume: float | None = None,
        deviation: int | None = None,
        comment: str = "",
        dry_run: bool = False,
        client_id: str | None = None,
    ) -> dict[str, Any]:
        """Close a position fully (or partially if volume is given).
        Reuse the same client_id when retrying (see market_order)."""
        self._require_trading(dry_run)
        cid = self._client_id(client_id)
        if client_id is not None and not dry_run:
            existing = await self._find_by_cid(cid)
            if existing:
                return self._existing_result(existing, cid)
        pos = await self._get_position(ticket)
        tick = await self._run(mt5.symbol_info_tick, pos.symbol)
        info = await self._run(mt5.symbol_info, pos.symbol)
        if tick is None or info is None:
            raise MT5OrderError(f"No price for {pos.symbol}")
        is_buy = pos.type == mt5.POSITION_TYPE_BUY
        request = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": pos.symbol, "position": int(ticket),
            "volume": float(volume) if volume else pos.volume,
            "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
            "price": tick.bid if is_buy else tick.ask,
            "deviation": deviation if deviation is not None else self.default_deviation,
            "magic": pos.magic, "comment": self._tag(comment, cid),
            "type_time": mt5.ORDER_TIME_GTC, "type_filling": self._filling(info),
        }
        return await self._send(request, dry_run, cid)

    async def modify_position(
        self,
        ticket: int,
        sl: float | None = None,
        tp: float | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Change SL/TP (idempotent by nature: resending the same values is
        harmless). A value left as None keeps the current one. After an
        ambiguous response, the position's SL/TP are compared with the request."""
        self._require_trading(dry_run)
        pos = await self._get_position(ticket)
        request = {
            "action": mt5.TRADE_ACTION_SLTP, "position": int(ticket), "symbol": pos.symbol,
            "sl": float(sl) if sl is not None else pos.sl,
            "tp": float(tp) if tp is not None else pos.tp,
        }
        return await self._send(request, dry_run)
