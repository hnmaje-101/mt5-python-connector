"""mt5_connectors — MT5 execution + resilient market-data connectors."""
import logging

from .base import BaseConnector
from .exceptions import (
    ConnectorError,
    ExternalDataError,
    MT5ConnectionError,
    MT5DataError,
    MT5OrderAmbiguousError,
    MT5OrderError,
)
from .external import ExternalDataConnector
from .hybrid import HybridConnector
from .mt5 import MT5Connector

logging.getLogger("mt5_connectors").addHandler(logging.NullHandler())

__version__ = "1.0.0"
__author__ = "Roger David Fernandez Pineda"
__all__ = [
    "BaseConnector", "MT5Connector", "ExternalDataConnector", "HybridConnector",
    "ConnectorError", "MT5ConnectionError", "MT5DataError", "MT5OrderError",
    "MT5OrderAmbiguousError", "ExternalDataError",
]
