"""External market-data connector (for brokers that block data reads in MT5).

Providers (in priority order, configurable): Twelve Data (API key, rate-limited)
and yfinance (free, no key). Custom providers can be plugged in (duck-typed).

IMPORTANT: external prices are NOT your broker's prices. Yahoo's GC=F is a
futures contract, not spot XAU/USD. Use HybridConnector's price-offset
calibration if you trade on MT5 using these prices.
"""
from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol

import pandas as pd

try:
    import yfinance as yf
except ImportError:  # optional
    yf = None

try:
    import httpx
except ImportError:  # optional
    httpx = None

from .base import BaseConnector
from .exceptions import ExternalDataError
from .log import get_logger
from .utils import drop_forming_candle, finalize_ohlcv, resample_ohlcv, tf_minutes, to_utc

logger = get_logger("external")

# Internal symbol -> per-provider symbol. Extend via ExternalDataConnector(symbol_map=...).
# Broker suffixes/prefixes (XAUUSDP, XAUUSD.m, XAUUSDm) are matched by prefix.
DEFAULT_SYMBOL_MAP: dict[str, dict[str, str]] = {
    "XAUUSD": {"twelvedata": "XAU/USD", "yfinance": "GC=F"},
    "XAGUSD": {"twelvedata": "XAG/USD", "yfinance": "SI=F"},
    "EURUSD": {"twelvedata": "EUR/USD", "yfinance": "EURUSD=X"},
    "GBPUSD": {"twelvedata": "GBP/USD", "yfinance": "GBPUSD=X"},
    "USDJPY": {"twelvedata": "USD/JPY", "yfinance": "JPY=X"},
    "BTCUSD": {"twelvedata": "BTC/USD", "yfinance": "BTC-USD"},
}

TF_TWELVEDATA = {
    "M1": "1min", "M5": "5min", "M15": "15min", "M30": "30min",
    "H1": "1h", "H4": "4h", "D1": "1day", "W1": "1week", "MN1": "1month",
}
TF_YFINANCE = {  # H4 is built by resampling 1h
    "M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m",
    "H1": "1h", "H4": "1h", "D1": "1d", "W1": "1wk", "MN1": "1mo",
}
YF_PERIOD = {
    "1m": "7d", "5m": "60d", "15m": "60d", "30m": "60d",
    "1h": "730d", "1d": "5y", "1wk": "10y", "1mo": "max",
}


def _redact(text: str, secret: str | None) -> str:
    return text.replace(secret, "***") if secret else text


class RateLimiter:
    """Sliding-window limiter. try_acquire() never blocks."""

    def __init__(self, max_calls: int, period: float = 60.0) -> None:
        self.max_calls, self.period = max_calls, period
        self._calls: deque[float] = deque()

    def try_acquire(self) -> bool:
        now = time.monotonic()
        while self._calls and now - self._calls[0] >= self.period:
            self._calls.popleft()
        if len(self._calls) >= self.max_calls:
            return False
        self._calls.append(now)
        return True


class Provider(Protocol):
    name: str

    async def fetch_ohlcv(
        self, symbol: str, timeframe: str, bars: int, from_date: datetime | None
    ) -> pd.DataFrame | None: ...

    async def fetch_price(self, symbol: str) -> float | None: ...


class TwelveDataProvider:
    name = "twelvedata"
    BASE = "https://api.twelvedata.com"

    def __init__(self, api_key: str, calls_per_minute: int = 8, timeout: float = 15.0) -> None:
        self._key = api_key
        self._timeout = timeout
        self._limiter = RateLimiter(calls_per_minute, 60.0)

    async def _get(self, path: str, params: dict[str, Any]) -> dict | None:
        if not self._limiter.try_acquire():
            logger.debug("Twelve Data rate limit reached; skipping to next provider")
            return None
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(
                    f"{self.BASE}/{path}", params={**params, "apikey": self._key}
                )
                resp.raise_for_status()
                data = resp.json()
        except Exception as exc:  # never log the URL/key
            logger.warning("Twelve Data request failed: %s", _redact(str(exc), self._key))
            return None
        if isinstance(data, dict) and data.get("status") == "error":
            logger.warning("Twelve Data error: %s", data.get("message"))
            return None
        return data

    async def fetch_ohlcv(self, symbol, timeframe, bars, from_date):
        interval = TF_TWELVEDATA.get(timeframe)
        if not interval:
            return None
        params: dict[str, Any] = {
            "symbol": symbol, "interval": interval, "timezone": "UTC",
            "outputsize": 5000 if from_date else min(int(bars), 5000),
        }
        if from_date:
            params["start_date"] = to_utc(from_date).strftime("%Y-%m-%d %H:%M:%S")
        data = await self._get("time_series", params)
        values = (data or {}).get("values")
        if not values:
            return None
        df = pd.DataFrame(values)
        df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
        df = df.set_index("datetime").rename(columns={"volume": "tick_volume"})
        return df.sort_index()

    async def fetch_price(self, symbol):
        data = await self._get("price", {"symbol": symbol})
        try:
            price = float((data or {}).get("price", 0))
        except (TypeError, ValueError):
            return None
        return price if price > 0 else None


class YFinanceProvider:
    name = "yfinance"

    def __init__(self) -> None:
        if yf is None:
            raise ImportError("yfinance is not installed: pip install yfinance")

    async def fetch_ohlcv(self, symbol, timeframe, bars, from_date):
        return await asyncio.to_thread(self._fetch, symbol, timeframe, from_date)

    def _fetch(self, symbol, timeframe, from_date):
        yf_tf = TF_YFINANCE.get(timeframe)
        if not yf_tf:
            return None
        kwargs: dict[str, Any] = {"interval": yf_tf, "auto_adjust": True, "prepost": False}
        if from_date:
            kwargs["start"] = to_utc(from_date)
        else:
            kwargs["period"] = YF_PERIOD[yf_tf]
        try:
            df = yf.Ticker(symbol).history(**kwargs)
        except Exception as exc:
            logger.warning("yfinance fetch failed: %s", exc)
            return None
        if df is None or df.empty:
            return None
        df.index = pd.to_datetime(df.index, utc=True)
        df = df.rename(columns={
            "Open": "open", "High": "high", "Low": "low",
            "Close": "close", "Volume": "tick_volume",
        })[["open", "high", "low", "close", "tick_volume"]].sort_index()
        if timeframe == "H4":
            df = resample_ohlcv(df, "4h")
        return df

    async def fetch_price(self, symbol):
        return await asyncio.to_thread(self._price, symbol)

    @staticmethod
    def _price(symbol):
        try:
            fast = yf.Ticker(symbol).fast_info
            try:
                price = fast["last_price"]
            except Exception:
                price = getattr(fast, "last_price", None)
            return float(price) if price else None
        except Exception:
            return None


@dataclass
class _CacheEntry:
    df: pd.DataFrame
    requested: int
    ts: float


class ExternalDataConnector(BaseConnector):
    """OHLCV + price from external providers, with fallback, caching and limits.

    Args:
        twelvedata_key: API key (free plan: 8 calls/min, 800/day).
        providers: priority order. Names ("twelvedata", "yfinance") or custom
            provider objects with name / fetch_ohlcv / fetch_price.
        symbol_map: extra/override {"XAUUSD": {"twelvedata": "...", "yfinance": "..."}}.
        ohlcv_cache_ttl / price_cache_ttl: seconds.
    """

    def __init__(
        self,
        twelvedata_key: str | None = None,
        providers: tuple = ("twelvedata", "yfinance"),
        symbol_map: dict[str, dict[str, str]] | None = None,
        ohlcv_cache_ttl: float = 60.0,
        price_cache_ttl: float = 3.0,
        twelvedata_calls_per_minute: int = 8,
    ) -> None:
        self._symbol_map = {**DEFAULT_SYMBOL_MAP, **(symbol_map or {})}
        self._ohlcv_ttl, self._price_ttl = ohlcv_cache_ttl, price_cache_ttl
        self._cache: dict[tuple[str, str], _CacheEntry] = {}
        self._price_cache: dict[str, tuple[dict, float]] = {}
        self.last_source: str | None = None
        self._providers: list[Any] = []

        for item in providers:
            if item == "twelvedata":
                if twelvedata_key and httpx is not None:
                    self._providers.append(
                        TwelveDataProvider(twelvedata_key, twelvedata_calls_per_minute)
                    )
                elif twelvedata_key:
                    logger.warning("httpx not installed: Twelve Data disabled")
            elif item == "yfinance":
                if yf is not None:
                    self._providers.append(YFinanceProvider())
                else:
                    logger.warning("yfinance not installed: provider disabled")
            elif hasattr(item, "fetch_ohlcv"):
                self._providers.append(item)
            else:
                raise ValueError(f"Unknown provider: {item!r}")
        if not self._providers:
            logger.warning("ExternalDataConnector has no usable providers")

    # ── symbols ───────────────────────────────────────────────

    def _provider_symbol(self, symbol: str, provider_name: str) -> str | None:
        s = symbol.upper()
        key = s if s in self._symbol_map else next(
            (k for k in sorted(self._symbol_map, key=len, reverse=True) if s.startswith(k)),
            None,
        )
        return self._symbol_map[key].get(provider_name) if key else None

    # ── interface ─────────────────────────────────────────────

    async def connect(self) -> None:
        if not await self.is_connected():
            logger.warning("No external data provider responded")

    async def disconnect(self) -> None:
        pass

    async def is_connected(self) -> bool:
        try:
            await self.get_current_price("XAUUSD")
            return True
        except Exception:
            return False

    async def get_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        bars: int | None = 500,
        from_date: datetime | None = None,
        closed_only: bool = True,
    ) -> pd.DataFrame:
        tf = timeframe.upper()
        tf_minutes(tf)  # validates
        need = (int(bars) if bars else 5000) + 1  # +1: forming candle
        key = (symbol.upper(), tf)

        raw = None
        entry = self._cache.get(key) if from_date is None else None
        if entry and time.monotonic() - entry.ts < self._ohlcv_ttl and entry.requested >= need:
            raw = entry.df
        if raw is None:
            raw = await self._fetch_ohlcv(symbol, tf, need, from_date)
            if from_date is None:
                self._cache[key] = _CacheEntry(raw, need, time.monotonic())

        df = drop_forming_candle(raw, tf) if closed_only else raw
        return df.tail(int(bars)) if bars else df

    async def _fetch_ohlcv(self, symbol, tf, need, from_date) -> pd.DataFrame:
        for provider in self._providers:
            sym = self._provider_symbol(symbol, provider.name)
            if sym is None:
                continue
            try:
                df = await provider.fetch_ohlcv(sym, tf, need, from_date)
            except Exception as exc:
                logger.warning("%s OHLCV failed: %s", provider.name, exc)
                continue
            if df is not None and not df.empty:
                self.last_source = provider.name
                return finalize_ohlcv(df)
        raise ExternalDataError(
            f"No external provider returned OHLCV for {symbol}/{tf}. Check your "
            "connection, API key, rate limits and symbol_map."
        )

    async def get_current_price(self, symbol: str) -> dict[str, Any]:
        """Last price. bid/ask are NOT real quotes: both equal `last`, and
        `estimated` is True. Do not use for spread or execution decisions."""
        cached = self._price_cache.get(symbol.upper())
        if cached and time.monotonic() - cached[1] < self._price_ttl:
            return cached[0]

        price, source = None, None
        for provider in self._providers:
            sym = self._provider_symbol(symbol, provider.name)
            if sym is None:
                continue
            try:
                price = await provider.fetch_price(sym)
            except Exception as exc:
                logger.warning("%s price failed: %s", provider.name, exc)
                continue
            if price:
                source = provider.name
                break
        if not price:  # fall back to the latest candle's close
            df = await self.get_ohlcv(symbol, "M1", bars=1, closed_only=False)
            price, source = float(df["close"].iloc[-1]), f"{self.last_source}:candle"

        result = {
            "symbol": symbol, "bid": price, "ask": price, "last": price,
            "spread_points": None, "time": datetime.now(timezone.utc),
            "volume": 0, "source": source, "estimated": True,
        }
        self._price_cache[symbol.upper()] = (result, time.monotonic())
        self.last_source = source
        return result
