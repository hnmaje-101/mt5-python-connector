"""Common interface implemented by every connector."""
from __future__ import annotations

import abc
from datetime import datetime
from typing import Any

import pandas as pd

from .utils import TIMEFRAME_MINUTES  # noqa: F401  (re-exported)


class BaseConnector(abc.ABC):
    """Async interface shared by MT5Connector, ExternalDataConnector, HybridConnector."""

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.disconnect()

    @abc.abstractmethod
    async def connect(self) -> None: ...

    @abc.abstractmethod
    async def disconnect(self) -> None: ...

    @abc.abstractmethod
    async def is_connected(self) -> bool: ...

    @abc.abstractmethod
    async def get_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        bars: int | None = 500,
        from_date: datetime | None = None,
        closed_only: bool = True,
    ) -> pd.DataFrame:
        """OHLCV candles. Columns: open, high, low, close, tick_volume, spread,
        real_volume, log_return. Index: UTC DatetimeIndex (oldest first).
        With closed_only=True the still-forming candle is excluded."""

    @abc.abstractmethod
    async def get_current_price(self, symbol: str) -> dict[str, Any]:
        """Dict with symbol, bid, ask, last, spread_points, time, volume."""

    async def get_account_summary(self) -> dict[str, Any]:
        return {}

    async def get_symbol_info(self, symbol: str) -> dict[str, Any]:
        return {}
