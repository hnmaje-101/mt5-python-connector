"""Hybrid connector: MT5 for execution (and data when available), external
providers as automatic fallback for data, with price-offset calibration."""
from __future__ import annotations

import time
from datetime import datetime
from typing import Any

import pandas as pd

from .base import BaseConnector
from .exceptions import MT5ConnectionError
from .external import ExternalDataConnector
from .log import get_logger
from .mt5 import MT5Connector

logger = get_logger("hybrid")


class _Health:
    """Tracks a capability; after a failure it is retried every `retry` seconds."""

    def __init__(self, retry: float) -> None:
        self.retry, self.ok, self.failed_at = retry, True, 0.0

    def should_try(self) -> bool:
        return self.ok or time.monotonic() - self.failed_at >= self.retry

    def success(self) -> bool:
        """Returns True if this is a recovery."""
        recovered = not self.ok
        self.ok = True
        return recovered

    def failure(self) -> bool:
        """Returns True if this is a new failure (state changed)."""
        changed = self.ok
        self.ok, self.failed_at = False, time.monotonic()
        return changed


class HybridConnector(BaseConnector):
    """MT5 for orders; MT5 for data when it works, external data when it doesn't.

    - Data failures in MT5 switch to external automatically and MT5 is retried
      every `retry_seconds` (it recovers on its own).
    - External prices can be shifted by (MT5 mid price - external price) so
      SL/TP computed from them match your broker's price space. Calibration
      needs MT5 to provide a price; otherwise offset stays at its last value
      (0 at start) and status() says so.
    - Orders always go to MT5 and fail loudly if MT5 is down.

    Pass ready-made connectors (mt5_connector=, external=) or the raw settings
    (login, password, server, path, twelvedata_key).
    """

    def __init__(
        self,
        mt5_connector: MT5Connector | None = None,
        external: ExternalDataConnector | None = None,
        *,
        login: int | None = None,
        password: str | None = None,
        server: str | None = None,
        path: str | None = None,
        twelvedata_key: str | None = None,
        symbol: str = "XAUUSD",
        allow_trading: bool = False,
        retry_seconds: float = 120.0,
        apply_offset: bool = True,
        offset_refresh_seconds: float = 30.0,
        max_offset_pct: float = 1.0,
    ) -> None:
        self._mt5 = mt5_connector or MT5Connector(
            login, password, server, path, allow_trading=allow_trading
        )
        self._ext = external or ExternalDataConnector(twelvedata_key=twelvedata_key)
        self.symbol = symbol  # used to probe MT5 data at connect()
        self._retry = retry_seconds
        self.apply_offset = apply_offset
        self._offset_refresh = offset_refresh_seconds
        self._max_offset_pct = max_offset_pct

        self._mt5_connected = False
        self._last_connect_try = 0.0
        self._health = {"ohlcv": _Health(retry_seconds), "price": _Health(retry_seconds)}
        self._offset = 0.0
        self._offset_ok = False
        self._offset_ts: float | None = None   # last successful calibration
        self._offset_try_ts: float | None = None
        self._offset_warned = False
        self.last_error: str | None = None

    @property
    def mt5(self) -> MT5Connector:
        return self._mt5

    @property
    def external(self) -> ExternalDataConnector:
        return self._ext

    # ── connection ────────────────────────────────────────────

    async def _connect_mt5(self, max_attempts: int | None = None) -> None:
        self._last_connect_try = time.monotonic()
        try:
            await self._mt5.connect(max_attempts=max_attempts)
            self._mt5_connected = True
        except MT5ConnectionError as exc:
            self._mt5_connected = False
            self.last_error = f"MT5 connect: {exc}"
            logger.warning("MT5 not available: %s", exc)

    async def _ensure_mt5(self) -> bool:
        if self._mt5_connected:
            return True
        if time.monotonic() - self._last_connect_try < self._retry:
            return False
        await self._connect_mt5(max_attempts=1)
        if self._mt5_connected:
            logger.info("MT5 reconnected")
        return self._mt5_connected

    async def connect(self) -> None:
        await self._connect_mt5()
        if self._mt5_connected:
            try:
                await self._mt5.get_ohlcv(self.symbol, "H1", bars=5)
            except Exception as exc:
                self._health["ohlcv"].failure()
                logger.warning("MT5 cannot provide OHLCV (%s): using external data", exc)
            try:
                await self._mt5.get_current_price(self.symbol)
            except Exception as exc:
                self._health["price"].failure()
                logger.warning("MT5 cannot provide prices (%s): using external data", exc)
        else:
            logger.warning("MT5 down: external data only; orders will fail until MT5 is back")
        logger.info("Hybrid ready: %s", self.status())

    async def disconnect(self) -> None:
        if self._mt5_connected:
            await self._mt5.disconnect()
            self._mt5_connected = False
        await self._ext.disconnect()

    async def is_connected(self) -> bool:
        """True when MT5 (order execution) is up. See is_data_available()."""
        return self._mt5_connected and await self._mt5.is_connected()

    async def is_data_available(self) -> bool:
        return (self._mt5_connected and self._health["ohlcv"].ok) or await self._ext.is_connected()

    # ── failure handling ──────────────────────────────────────

    async def _mt5_failed(self, kind: str, exc: Exception) -> None:
        self.last_error = f"MT5 {kind}: {exc}"
        if self._health[kind].failure():
            logger.warning("MT5 %s failed (%s): falling back to external data", kind, exc)
        try:
            if not await self._mt5.is_connected():
                self._mt5_connected = False
        except Exception:
            self._mt5_connected = False

    def _mt5_ok(self, kind: str) -> None:
        if self._health[kind].success():
            logger.info("MT5 %s recovered", kind)

    # ── offset calibration ────────────────────────────────────

    async def _get_offset(self, symbol: str, ext_last: float | None = None) -> float:
        if not self.apply_offset:
            return 0.0
        now = time.monotonic()
        if self._offset_try_ts is not None and now - self._offset_try_ts < self._offset_refresh:
            return self._offset
        self._offset_try_ts = now
        if not self._mt5_connected:
            return self._offset
        try:
            quote = await self._mt5.get_current_price(symbol)
            mt5_mid = (quote["bid"] + quote["ask"]) / 2
            if ext_last is None:
                ext_last = (await self._ext.get_current_price(symbol))["last"]
        except Exception as exc:
            logger.debug("Offset calibration unavailable: %s", exc)
            return self._offset
        offset = mt5_mid - ext_last
        if ext_last and abs(offset) / ext_last * 100 > self._max_offset_pct:
            logger.warning("Price offset %.4f exceeds %.2f%%: ignored", offset, self._max_offset_pct)
            return self._offset
        self._offset, self._offset_ok, self._offset_ts = offset, True, now
        return offset

    def _warn_uncalibrated(self) -> None:
        if self.apply_offset and not self._offset_ok and not self._offset_warned:
            self._offset_warned = True
            logger.warning(
                "External prices are NOT calibrated to MT5. SL/TP computed from them "
                "may differ from your broker's price. See status()['offset_calibrated']."
            )

    # ── data ──────────────────────────────────────────────────

    async def get_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        bars: int | None = 500,
        from_date: datetime | None = None,
        closed_only: bool = True,
    ) -> pd.DataFrame:
        if await self._ensure_mt5() and self._health["ohlcv"].should_try():
            try:
                df = await self._mt5.get_ohlcv(symbol, timeframe, bars, from_date, closed_only)
                self._mt5_ok("ohlcv")
                df.attrs["source"] = "mt5"
                return df
            except Exception as exc:
                await self._mt5_failed("ohlcv", exc)

        df = await self._ext.get_ohlcv(symbol, timeframe, bars, from_date, closed_only)
        offset = await self._get_offset(symbol)
        if offset:
            df = df.copy()
            df[["open", "high", "low", "close"]] += offset
        else:
            self._warn_uncalibrated()
        df.attrs.update(source="external", price_offset=offset)
        return df

    async def get_current_price(self, symbol: str) -> dict[str, Any]:
        if await self._ensure_mt5() and self._health["price"].should_try():
            try:
                price = await self._mt5.get_current_price(symbol)
                self._mt5_ok("price")
                return price
            except Exception as exc:
                await self._mt5_failed("price", exc)

        price = dict(await self._ext.get_current_price(symbol))
        offset = await self._get_offset(symbol, ext_last=price["last"])
        if offset:
            for k in ("bid", "ask", "last"):
                price[k] += offset
        else:
            self._warn_uncalibrated()
        price.update(price_offset=offset, offset_applied=bool(offset))
        return price

    async def get_account_summary(self) -> dict[str, Any]:
        if await self._ensure_mt5():
            return await self._mt5.get_account_summary()
        return {"note": "MT5 not connected"}

    async def get_symbol_info(self, symbol: str) -> dict[str, Any]:
        if await self._ensure_mt5():
            return await self._mt5.get_symbol_info(symbol)
        return {}

    # ── orders (always MT5) ───────────────────────────────────

    async def _require_mt5(self) -> MT5Connector:
        if not await self._ensure_mt5():
            raise MT5ConnectionError("MT5 is not connected: orders cannot be executed")
        return self._mt5

    async def market_order(self, *args, **kwargs) -> dict[str, Any]:
        return await (await self._require_mt5()).market_order(*args, **kwargs)

    async def close_position(self, *args, **kwargs) -> dict[str, Any]:
        return await (await self._require_mt5()).close_position(*args, **kwargs)

    async def modify_position(self, *args, **kwargs) -> dict[str, Any]:
        return await (await self._require_mt5()).modify_position(*args, **kwargs)

    async def get_positions(self, symbol: str | None = None) -> list[dict[str, Any]]:
        return await (await self._require_mt5()).get_positions(symbol)

    # ── diagnostics ───────────────────────────────────────────

    def status(self) -> dict[str, Any]:
        mt5_ohlcv = self._mt5_connected and self._health["ohlcv"].ok
        mt5_price = self._mt5_connected and self._health["price"].ok
        age = None if self._offset_ts is None else round(time.monotonic() - self._offset_ts, 1)
        return {
            "mt5_connected": self._mt5_connected,
            "orders_available": self._mt5_connected,
            "ohlcv_source": "mt5" if mt5_ohlcv else "external",
            "price_source": "mt5" if mt5_price else "external",
            "external_last_source": self._ext.last_source,
            "price_offset": self._offset,
            "offset_calibrated": self._offset_ok,
            "offset_age_seconds": age,
            "last_error": self.last_error,
        }
