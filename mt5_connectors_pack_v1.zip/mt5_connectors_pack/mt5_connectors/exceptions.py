"""Exceptions raised by mt5_connectors."""
from __future__ import annotations


class ConnectorError(Exception):
    """Base class for all connector errors."""


class MT5ConnectionError(ConnectorError):
    """MT5 terminal could not be reached / initialized."""


class MT5DataError(ConnectorError):
    """MT5 returned no data or an invalid request was made."""


class MT5OrderError(ConnectorError):
    """An order was rejected, or trading is disabled."""

    def __init__(self, message: str, retcode: int | None = None) -> None:
        super().__init__(message)
        self.retcode = retcode


class MT5OrderAmbiguousError(MT5OrderError):
    """The outcome of an order could not be determined (timeout / lost reply).

    The connector already queried MT5 (positions + deal history) to reconcile.
    `not_found=True`: every check succeeded and found nothing (a retry is
    probably safe, but call reconcile(client_id) once more first).
    `not_found=False`: the checks themselves failed — do NOT retry blindly.
    """

    def __init__(self, message, client_id=None, not_found=False, retcode=None):
        super().__init__(message, retcode)
        self.client_id = client_id
        self.not_found = not_found


class ExternalDataError(ConnectorError):
    """No external provider could return the requested data."""
