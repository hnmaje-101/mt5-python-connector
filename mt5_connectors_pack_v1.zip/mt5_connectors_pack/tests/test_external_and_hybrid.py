"""Offline tests: fake providers and a fake MT5 (no network, no MetaTrader)."""
import asyncio

import pandas as pd
import pytest

from mt5_connectors import ExternalDataConnector, HybridConnector
from mt5_connectors.base import BaseConnector
from mt5_connectors.exceptions import ExternalDataError, MT5ConnectionError, MT5DataError
from mt5_connectors.utils import drop_forming_candle, finalize_ohlcv, resample_ohlcv

run = asyncio.run


def make_df(n, price=2000.0, freq="1h"):
    end = pd.Timestamp.now(tz="UTC").floor(freq)  # last row = forming candle
    idx = pd.date_range(end=end, periods=n, freq=freq, tz="UTC")
    return pd.DataFrame(
        {"open": price, "high": price, "low": price, "close": price, "tick_volume": 1},
        index=idx,
    )


class FakeProvider:
    name = "fake"

    def __init__(self, price=2000.0):
        self.price, self.ohlcv_calls, self.last_symbol = price, 0, None

    async def fetch_ohlcv(self, symbol, timeframe, bars, from_date):
        self.ohlcv_calls += 1
        self.last_symbol = symbol
        return make_df(bars, self.price)

    async def fetch_price(self, symbol):
        return self.price


def ext(provider=None):
    return ExternalDataConnector(
        providers=(provider or FakeProvider(),),
        symbol_map={"XAUUSD": {"fake": "GOLD"}},
    )


# ── utils ────────────────────────────────────────────────────

def test_finalize_contract():
    out = finalize_ohlcv(make_df(5))
    for col in ("open", "high", "low", "close", "tick_volume", "spread", "real_volume", "log_return"):
        assert col in out.columns
    assert out["log_return"].iloc[0] == 0.0


def test_drop_forming_candle():
    df = make_df(5)
    assert len(drop_forming_candle(df, "H1")) == 4


def test_resample_4h():
    df = make_df(48)
    out = resample_ohlcv(df, "4h")
    assert len(out) >= 11 and out["tick_volume"].iloc[1] == 4


# ── external ─────────────────────────────────────────────────

def test_closed_only_and_bars():
    c = ext()
    df = run(c.get_ohlcv("XAUUSD", "H1", bars=5))
    assert len(df) == 5
    assert df.index[-1] + pd.Timedelta(hours=1) <= pd.Timestamp.now(tz="UTC")


def test_cache_is_keyed_by_size():
    """Regression: a cached 1-bar request must not serve a 500-bar request."""
    p = FakeProvider()
    c = ext(p)
    run(c.get_ohlcv("XAUUSD", "H1", bars=1))
    df = run(c.get_ohlcv("XAUUSD", "H1", bars=500))
    assert len(df) == 500 and p.ohlcv_calls == 2
    run(c.get_ohlcv("XAUUSD", "H1", bars=10))  # served from the 500-bar cache
    assert p.ohlcv_calls == 2


def test_broker_suffix_symbol_resolution():
    p = FakeProvider()
    run(ext(p).get_ohlcv("XAUUSDP", "H1", bars=3))
    assert p.last_symbol == "GOLD"


def test_unknown_symbol_raises():
    with pytest.raises(ExternalDataError):
        run(ext().get_ohlcv("NOPE", "H1", bars=3))


def test_price_is_flagged_estimated():
    price = run(ext().get_current_price("XAUUSD"))
    assert price["estimated"] and price["spread_points"] is None


# ── hybrid ───────────────────────────────────────────────────

class FakeMT5(BaseConnector):
    def __init__(self, mid=2005.0):
        self.mid, self.down, self.fail_ohlcv = mid, False, False
        self.connected = False

    async def connect(self, max_attempts=None):
        if self.down:
            raise MT5ConnectionError("down")
        self.connected = True

    async def disconnect(self):
        self.connected = False

    async def is_connected(self):
        return self.connected and not self.down

    async def get_ohlcv(self, symbol, timeframe, bars=500, from_date=None, closed_only=True):
        if self.fail_ohlcv:
            raise MT5DataError("blocked by broker")
        return finalize_ohlcv(make_df(bars, self.mid))

    async def get_current_price(self, symbol):
        return {"symbol": symbol, "bid": self.mid - 0.1, "ask": self.mid + 0.1,
                "last": self.mid, "spread_points": 20.0, "volume": 0}

    async def market_order(self, *a, **k):
        return {"retcode": 10009}


def hybrid(mt5, retry=60.0):
    return HybridConnector(mt5_connector=mt5, external=ext(), retry_seconds=retry,
                           offset_refresh_seconds=0)


def test_uses_mt5_when_healthy():
    h = hybrid(FakeMT5())
    run(h.connect())
    df = run(h.get_ohlcv("XAUUSD", "H1", bars=5))
    assert df.attrs["source"] == "mt5" and h.status()["ohlcv_source"] == "mt5"


def test_fallback_to_external_with_offset():
    mt5 = FakeMT5(mid=2005.0)
    mt5.fail_ohlcv = True
    h = hybrid(mt5)
    run(h.connect())
    df = run(h.get_ohlcv("XAUUSD", "H1", bars=5))
    assert df.attrs["source"] == "external"
    assert (df["close"] == 2005.0).all()          # 2000 external + 5 offset
    st = h.status()
    assert st["ohlcv_source"] == "external" and st["offset_calibrated"]
    price = run(h.get_current_price("XAUUSD"))    # price path still on MT5
    assert price["last"] == 2005.0


def test_mt5_recovers_automatically():
    mt5 = FakeMT5()
    mt5.fail_ohlcv = True
    h = hybrid(mt5, retry=0.0)
    run(h.connect())
    assert run(h.get_ohlcv("XAUUSD", "H1", bars=3)).attrs["source"] == "external"
    mt5.fail_ohlcv = False
    assert run(h.get_ohlcv("XAUUSD", "H1", bars=3)).attrs["source"] == "mt5"


def test_orders_fail_loudly_when_mt5_down():
    mt5 = FakeMT5()
    mt5.down = True
    h = hybrid(mt5)
    run(h.connect())
    assert run(h.get_ohlcv("XAUUSD", "H1", bars=3)).attrs["source"] == "external"
    assert run(h.is_connected()) is False
    with pytest.raises(MT5ConnectionError):
        run(h.market_order("XAUUSD", "buy", 0.01))
