"""Order-recovery tests against a fake MetaTrader5 module (no terminal needed)."""
import asyncio
from types import SimpleNamespace as NS

import pytest

import mt5_connectors.mt5 as m
from mt5_connectors import MT5Connector, MT5OrderAmbiguousError

run = asyncio.run


class FakeMT5Module:
    TRADE_ACTION_DEAL, TRADE_ACTION_SLTP = 1, 2
    ORDER_TYPE_BUY, ORDER_TYPE_SELL, ORDER_TIME_GTC = 0, 1, 0
    ORDER_FILLING_FOK, ORDER_FILLING_IOC, ORDER_FILLING_RETURN = 0, 1, 2
    SYMBOL_FILLING_FOK, SYMBOL_FILLING_IOC = 1, 2
    TRADE_RETCODE_DONE, TRADE_RETCODE_PLACED, TRADE_RETCODE_DONE_PARTIAL = 10009, 10008, 10010
    TRADE_RETCODE_TIMEOUT, TRADE_RETCODE_CONNECTION, TRADE_RETCODE_ERROR = 10012, 10031, 10006
    POSITION_TYPE_BUY = 0

    def __init__(self, mode):
        self.mode = mode  # done | timeout_executed | timeout_lost
        self.sent, self.positions, self.deals, self._next = 0, [], [], 1000

    # market data / symbol
    def symbol_select(self, s, e): return True
    def last_error(self): return (1, "Success")
    def symbol_info(self, s):
        return NS(volume_min=0.01, volume_max=100.0, volume_step=0.01,
                  filling_mode=2, digits=2, point=0.01, name=s)
    def symbol_info_tick(self, s): return NS(ask=2000.1, bid=2000.0)

    # orders
    def order_send(self, req):
        self.sent += 1
        if self.mode != "timeout_lost":
            self._apply(req)
        if self.mode == "done":
            return NS(retcode=10009, comment="ok", order=1, deal=1, volume=req["volume"], price=req["price"])
        return NS(retcode=10012, comment="timeout")

    def _apply(self, req):
        self._next += 1
        if "position" in req:
            self.positions = [p for p in self.positions if p.ticket != req["position"]]
        else:
            self.positions.append(NS(ticket=self._next, symbol=req["symbol"], type=0,
                                     volume=req["volume"], price_open=req["price"],
                                     comment=req["comment"], magic=req["magic"], sl=0.0, tp=0.0))
        self.deals.append(NS(ticket=self._next, order=self._next, position_id=self._next,
                             volume=req["volume"], price=req["price"], comment=req["comment"]))

    def positions_get(self, symbol=None, ticket=None):
        out = [p for p in self.positions
               if (symbol is None or p.symbol == symbol) and (ticket is None or p.ticket == ticket)]
        return tuple(out)

    def history_deals_get(self, date_from, date_to): return tuple(self.deals)


def connector(monkeypatch, mode):
    fake = FakeMT5Module(mode)
    monkeypatch.setattr(m, "mt5", fake)
    conn = MT5Connector(allow_trading=True, reconcile_attempts=2, reconcile_wait=0)
    return conn, fake


def test_ambiguous_but_executed_is_reconciled_not_duplicated(monkeypatch):
    conn, fake = connector(monkeypatch, "timeout_executed")
    res = run(conn.market_order("XAUUSD", "buy", 0.01))
    assert res["reconciled"] is True and res["kind"] == "position"
    assert fake.sent == 1                                 # never resent


def test_ambiguous_and_not_executed_raises_with_client_id(monkeypatch):
    conn, fake = connector(monkeypatch, "timeout_lost")
    with pytest.raises(MT5OrderAmbiguousError) as exc:
        run(conn.market_order("XAUUSD", "buy", 0.01))
    assert exc.value.not_found is True and exc.value.client_id
    assert fake.sent == 1                                 # no automatic retry


def test_same_client_id_is_idempotent(monkeypatch):
    conn, fake = connector(monkeypatch, "done")
    first = run(conn.market_order("XAUUSD", "buy", 0.01, client_id="abc12345"))
    again = run(conn.market_order("XAUUSD", "buy", 0.01, client_id="abc12345"))
    assert first["already_executed"] is False
    assert again["already_executed"] is True
    assert fake.sent == 1 and len(fake.positions) == 1


def test_retry_after_ambiguity_with_same_id_does_not_duplicate(monkeypatch):
    conn, fake = connector(monkeypatch, "timeout_executed")
    run(conn.market_order("XAUUSD", "buy", 0.01, client_id="retry001"))
    again = run(conn.market_order("XAUUSD", "buy", 0.01, client_id="retry001"))
    assert again["already_executed"] is True and fake.sent == 1


def test_ambiguous_close_is_reconciled(monkeypatch):
    conn, fake = connector(monkeypatch, "done")
    run(conn.market_order("XAUUSD", "buy", 0.01))
    ticket = fake.positions[0].ticket
    fake.mode = "timeout_executed"
    res = run(conn.close_position(ticket))
    assert res["reconciled"] is True and fake.positions == []


def test_bad_client_id_rejected(monkeypatch):
    conn, _ = connector(monkeypatch, "done")
    with pytest.raises(Exception):
        run(conn.market_order("XAUUSD", "buy", 0.01, client_id="x"))
