"""Self-test of MT5Connector against a REAL MT5 terminal — DEMO ACCOUNTS ONLY.

Run on the Windows machine where MetaTrader 5 is installed and logged in:

    pip install -r requirements.txt
    set MT5_LOGIN=...  set MT5_PASSWORD=...  set MT5_SERVER=...  (or use .env values)
    set SYMBOL=XAUUSD  (use your broker's exact symbol name, e.g. XAUUSDP)
    python examples/demo_check.py

It aborts if the account is not a demo account. It opens ONE 0.01-lot position
(magic 999), modifies SL/TP, and closes it. Output is saved to demo_report.txt
(no password is written). Paste that file back to get fixes.
"""
import asyncio
import os
import sys
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from mt5_connectors import MT5Connector  # noqa: E402

LINES: list[str] = []


def log(msg: str) -> None:
    print(msg)
    LINES.append(msg)


async def step(name, coro):
    try:
        result = await coro
        log(f"[PASS] {name}")
        return result
    except Exception as exc:
        log(f"[FAIL] {name}: {type(exc).__name__}: {exc}")
        LINES.append(traceback.format_exc())
        return None


async def main() -> int:
    symbol = os.getenv("SYMBOL", "XAUUSD")
    conn = MT5Connector(
        login=int(os.environ["MT5_LOGIN"]) if os.getenv("MT5_LOGIN") else None,
        password=os.getenv("MT5_PASSWORD"),
        server=os.getenv("MT5_SERVER"),
        path=os.getenv("MT5_PATH") or None,
        allow_trading=False,
        magic=999,
    )
    log(f"=== mt5_connectors demo check | {datetime.now(timezone.utc):%Y-%m-%d %H:%M UTC} | {symbol} ===")

    if await step("connect", conn.connect()) is None and not conn._connected:
        Path("demo_report.txt").write_text("\n".join(LINES), encoding="utf-8")
        return 1

    acct = await step("account summary", conn.get_account_summary()) or {}
    log(f"    server={acct.get('server')} trade_mode={acct.get('trade_mode')} "
        f"currency={acct.get('currency')} leverage={acct.get('leverage')}")
    if acct.get("trade_mode") != 0:  # 0 = ACCOUNT_TRADE_MODE_DEMO
        log("ABORT: this is NOT a demo account. Order tests are skipped for safety.")
        await conn.disconnect()
        Path("demo_report.txt").write_text("\n".join(LINES), encoding="utf-8")
        return 2

    info = await step("symbol info", conn.get_symbol_info(symbol)) or {}
    log(f"    digits={info.get('digits')} point={info.get('point')} "
        f"vol_min={info.get('volume_min')} vol_step={info.get('volume_step')} "
        f"filling_mode={info.get('filling_mode')}")
    price = await step("current price", conn.get_current_price(symbol))
    log(f"    {price}")
    for tf in ("M15", "H1", "H4"):
        df = await step(f"ohlcv {tf} x200 (closed only)", conn.get_ohlcv(symbol, tf, bars=200))
        if df is not None:
            log(f"    rows={len(df)} first={df.index[0]} last={df.index[-1]}")
    await step("ohlcv from_date (3 days, H1)", conn.get_ohlcv(
        symbol, "H1", bars=None, from_date=datetime.now(timezone.utc) - timedelta(days=3)))
    ticks = await step("ticks (500)", conn.get_ticks(
        symbol, datetime.now(timezone.utc) - timedelta(hours=6), count=500))
    if ticks is not None:
        log(f"    ticks={len(ticks)}")

    if not info or not price:
        log("Skipping orders: no symbol info/price.")
    else:
        vol = info.get("volume_min") or 0.01
        await step("order dry_run (order_check)", conn.market_order(symbol, "buy", vol, dry_run=True))

        conn.allow_trading = True  # demo confirmed above
        point, ask = info["point"], price["ask"]
        dist = 1000 * point
        sent = await step("REAL market BUY (demo)", conn.market_order(
            symbol, "buy", vol, sl=ask - dist, tp=ask + dist, comment="demo_check",
            client_id="demochk1"))
        again = await step("idempotent re-send, same client_id (must NOT open a 2nd position)",
                           conn.market_order(symbol, "buy", vol, client_id="demochk1"))
        if again is not None and not again.get("already_executed"):
            log("    [FAIL] second order was sent: idempotency did not detect the first one")
        positions = await step("get_positions", conn.get_positions(symbol)) or []
        mine = [p for p in positions if p["magic"] == 999]
        log(f"    open positions with magic 999: {len(mine)}")
        if mine:
            ticket = mine[-1]["ticket"]
            await step("modify SL/TP", conn.modify_position(
                ticket, sl=ask - dist * 1.5, tp=ask + dist * 1.5))
            await step("close position", conn.close_position(ticket, comment="demo_check"))
        elif sent:
            log("    WARNING: order reported OK but no position found (hedging/netting?).")

    await conn.disconnect()
    fails = sum(1 for line in LINES if line.startswith("[FAIL]"))
    log(f"=== done: {fails} failed step(s) ===")
    Path("demo_report.txt").write_text("\n".join(LINES), encoding="utf-8")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
