"""Quickstart: HybridConnector (MT5 for orders, external data fallback).

Copy .env.example to .env (or export the variables) before running.
"""
import asyncio
import logging
import os

from mt5_connectors import HybridConnector

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")


async def main() -> None:
    hybrid = HybridConnector(
        login=int(os.environ["MT5_LOGIN"]),
        password=os.environ["MT5_PASSWORD"],
        server=os.environ["MT5_SERVER"],
        path=os.getenv("MT5_PATH"),
        twelvedata_key=os.getenv("TWELVEDATA_KEY"),
        symbol=os.getenv("SYMBOL", "XAUUSD"),
        allow_trading=False,          # flip to True only when you are ready for real orders
    )
    async with hybrid:
        print(hybrid.status())
        df = await hybrid.get_ohlcv("XAUUSD", "H1", bars=200)
        print(df.tail(3), df.attrs)
        print(await hybrid.get_current_price("XAUUSD"))

        # Validate an order WITHOUT sending it (works even with allow_trading=False):
        print(await hybrid.market_order("XAUUSD", "buy", 0.01, dry_run=True))


if __name__ == "__main__":
    asyncio.run(main())
